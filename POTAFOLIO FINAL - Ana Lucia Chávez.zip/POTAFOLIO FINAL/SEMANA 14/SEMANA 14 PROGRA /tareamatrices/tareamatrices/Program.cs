﻿using System;

namespace ejercicio231
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] notas = new double[5, 6];
            string[] nombres = new string[5];

            for (int g = 0; g < 5; g++)
            {
                Console.WriteLine("Ingrese nombre");
                nombres[g] = Console.ReadLine();
                for (int a = 0; a < 6; a++)
                {
                    Random r = new Random();
                    notas[g, a] = r.Next(1, 100);
                }
            }
            for (int m = 0; m < 5; m++)
            {
                Console.Write(nombres[m] + "  ");
                for (int c = 0; c < 6; c++)
                {
                    Console.Write(notas[m, c] + "-");
                }
                Console.WriteLine();
            }

            //promedio por estudiante
            double[] promedioEstudiante = new double[5];
            for (int n = 0; n < 5; n++)
            {
                double promedio = 0;
                for (int c = 0; c < 6; c++)
                {
                    promedio += notas[n, c];
                }
                promedio /= 6;
                promedioEstudiante[n] = promedio;
            }

            //promedio por asignatura
            double[] promedioAsignatura = new double[6];
            for (int c = 0; c < 6; c++)
            {
                double promedio = 0;
                for (int f = 0; f < 5; f++)
                {
                    promedio += notas[f, c];
                }
                promedio /= 5;
                promedioAsignatura[c] = promedio;
            }

            //imprimir promedio por asignatura
            Console.WriteLine("Promedio por asignatura:");
            for (int c = 0; c < 6; c++)
            {
                Console.WriteLine("Asignatura " + c + ": " + promedioAsignatura[c]);
            }

            Console.ReadLine();
        }
    }
}
